package com.zensar.spring.boot.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.zensar.spring.boot.entity.Product;

@Repository
public interface ProductRepository extends CrudRepository<Product, Integer>{
	
	/*private static List<Product> products = null;
	private int length=1;

	static {

		products = new ArrayList<>();

		// products= Arrays.asList(new Product(1, "Mac", 75000), new Product(2, "IPad",
		// 50000));

		products.add(new Product(1, "Mac", 75000));
		products.add(new Product(2, "IPad", 50000));

	}

	
	public List<Product> getAllProducts() {
		return products;
	}

	
	public Product getProduct(Integer id) {

		for (Product product : products) {
			if (product.getProductId() == id) {
				return product;
			}
		}

		return null;

	}
	
	
	
	public Product insertProduct(Product product) {
		product.setProductId(++length);
		products.add(product);
		return product;
	}
	


*/
}
